rm data/testdb.mv.db
rm data/testdb.trace.db
rm data/ctdb.mv.db
rm data/ctdb.trace.db
mvn spring-boot:run -e -DskipTests 

