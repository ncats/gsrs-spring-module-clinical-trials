./mvnw clean package -DskipTests

cp target/applications.war $webapps_deployment/.
chmod a+r $webapps_deployment/applications.war
chown tomcat:tomcat $webapps_deployment/applications.war
