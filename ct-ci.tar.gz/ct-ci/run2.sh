rm data/testdb.mv.db
rm data/testdb.trace.db
rm data/ctdb.mv.db
rm data/ctdb.trace.db
mvn spring-boot:run -DskipTests -Dspring-boot.run.jvmArguments="-Dix.ginas.load.file=src/main/resources/rep18.gsrs"
